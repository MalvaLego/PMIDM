package com.example.calculadoraaaaaa

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat


class MainActivity : AppCompatActivity() {

    lateinit var btnPrueba: Button
    lateinit var tvEjercicio: TextView
    var contador:Int =0
    lateinit var bandera01: TextView
    lateinit var bandera02: TextView
    lateinit var bandera03: TextView
    lateinit var bandera04: TextView
    lateinit var bandera05: TextView
    lateinit var bandera06: TextView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        initComponents()
        initListeners()


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    private fun initComponents(){
        btnPrueba = findViewById(R.id.btnPrueba)
        tvEjercicio= findViewById(R.id.tvEjercicio)
        bandera01=findViewById(R.id.bandera01)
        bandera02=findViewById(R.id.bandera02)
        bandera03=findViewById(R.id.bandera03)
        bandera04=findViewById(R.id.bandera04)
        bandera05=findViewById(R.id.bandera05)
        bandera06=findViewById(R.id.bandera06)

    }

    private fun initListeners(){
    btnPrueba.setOnClickListener(){

        cambiobandera()
    }

    }

    private fun cont(){

        contador +=1
        tvEjercicio.text = contador.toString()
    }

    private fun spain(){
        ocultar()
        mostrar_horizontal()
        bandera01.setBackgroundResource(R.color.red)
        bandera02.setBackgroundResource(R.color.yellow)
        bandera03.setBackgroundResource(R.color.red)
    }

    private fun colombia(){
        ocultar()
        mostrar_horizontal()
        bandera01.setBackgroundResource(R.color.yellow)
        bandera02.setBackgroundResource(R.color.blue)
        bandera03.setBackgroundResource(R.color.red)
    }

    private fun italia(){
        ocultar()
        mostrar_vertical()
        bandera04.setBackgroundResource(R.color.brown)
        bandera05.setBackgroundResource(R.color.green)
        bandera06.setBackgroundResource(R.color.red)
    }

    private fun ocultar(){
        bandera01.visibility= View.GONE
        bandera02.visibility= View.GONE
        bandera03.visibility= View.GONE
        bandera04.visibility= View.GONE
        bandera05.visibility= View.GONE
        bandera06.visibility= View.GONE
    }

    private fun mostrar_horizontal(){
        bandera01.visibility= View.VISIBLE
        bandera02.visibility= View.VISIBLE
        bandera03.visibility= View.VISIBLE
    }

    private fun mostrar_vertical(){
        bandera04.visibility= View.VISIBLE
        bandera05.visibility= View.VISIBLE
        bandera06.visibility= View.VISIBLE
    }

    private fun cambiobandera(){
        cont()
        if (contador==1){
            spain()
        }else if (contador==2){
            colombia()
        }else{
            contador=0
            italia()
        }
    }



}